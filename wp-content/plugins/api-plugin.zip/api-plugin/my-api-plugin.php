<?php
/*
Plugin Name: API Plugin
Description: A simple plugin to integrate with an external API.
Version: 2.0
Author: Jamil
*/
require 'vendor/autoload.php';

// require 'C:\OSPanel\domains\wp-plugin\vendor\autoload.php';


use Psr\Log\LoggerInterface;
use Monolog\Logger;
use Monolog\Handler\StreamHandler;

// Security check to ensure the file is being called from WordPress
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

// Hook into the 'admin_menu' action to add a custom menu
add_action('admin_menu', 'my_api_plugin_menu');
add_action('admin_init', 'my_api_plugin_settings');
add_action('init', 'my_api_plugin_init');

register_activation_hook(__FILE__, 'my_api_plugin_activate');
register_deactivation_hook(__FILE__, 'my_api_plugin_deactivate');

function my_api_plugin_init() {
    if (file_exists(__DIR__ . '/vendor/autoload.php')) {
        require_once __DIR__ . '/vendor/autoload.php';
    }
}

function my_api_plugin_menu() {
    add_menu_page(
        'API Plugin',
        'API Plugin',
        'manage_options',
        'my-api-plugin',
        'my_api_plugin_page',
        'dashicons-admin-generic',
        6
    );
}

function my_api_plugin_settings() {
    register_setting('my_api_plugin_options_group', 'my_api_plugin_option_name');

    add_settings_section(
        'my_api_plugin_settings_section',
        'API Settings',
        'my_api_plugin_section_callback',
        'my-api-plugin'
    );

    add_settings_field(
        'my_api_plugin_field',
        'API Key',
        'my_api_plugin_field_callback',
        'my-api-plugin',
        'my_api_plugin_settings_section'
    );
}

function my_api_plugin_section_callback() {
    echo 'Enter your API settings below:';
}

function my_api_plugin_field_callback() {
    $setting = get_option('my_api_plugin_option_name');
    echo "<input type='text' name='my_api_plugin_option_name' value='" . esc_attr($setting) . "' />";
}

function my_api_plugin_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'my_api_plugin_tasks';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        title text NOT NULL,
        completed tinyint(1) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function my_api_plugin_deactivate() {
    // Optional: Drop table on deactivation
}

function my_api_plugin_sync_data(LoggerInterface $logger = null) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'my_api_plugin_tasks';

    $response = wp_remote_get('https://jsonplaceholder.typicode.com/todos');

    if (is_wp_error($response)) {
        if ($logger) {
            $logger->error('Error fetching data from API.');
        }
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $tasks = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        if ($logger) {
            $logger->error('Error decoding JSON response.');
        }
        return;
    }

    foreach ($tasks as $task) {
        $wpdb->replace($table_name, [
            'id' => $task['id'],
            'user_id' => $task['userId'],
            'title' => $task['title'],
            'completed' => $task['completed'] ? 1 : 0,
        ]);
    }

    if ($logger) {
        $logger->info('Data synchronized successfully.');
    }
}

function my_api_plugin_page() {
    if (isset($_POST['sync_data'])) {
        $logger = my_api_plugin_get_logger();
        my_api_plugin_sync_data($logger);
        echo '<div class="notice notice-success is-dismissible"><p>Data synchronized successfully.</p></div>';
    }

    $results = [];
    if (isset($_POST['search'])) {
        $title = sanitize_text_field($_POST['title']);
        global $wpdb;

        $table_name = $wpdb->prefix . 'my_api_plugin_tasks';
        $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE title LIKE %s", '%' . $wpdb->esc_like($title) . '%'));
    }
    ?>
    <div class="wrap">
        <h1>My API Plugin</h1>
        <p>For sync your data from API to database, click the button below:</p>
        <form method="post" action="">
            <input type="hidden" name="sync_data" value="1">
            <?php submit_button('Sync Data'); ?>
        </form>

        <h2>Search Tasks</h2>
        <form method="post" action="">
            <input type="text" name="title" placeholder="Enter title">
            <?php submit_button('Search', 'primary', 'search'); ?>
        </form>

        <?php if (!empty($results)) : ?>
            <h3>Search Results</h3>
            <ul>
                <?php foreach ($results as $task) : ?>
                    <li><?php echo esc_html($task->title); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    <?php
}

function my_api_plugin_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'my_api_plugin_tasks';
    $tasks = $wpdb->get_results("SELECT * FROM $table_name WHERE completed = 0 ORDER BY id DESC LIMIT 5");

    if (empty($tasks)) {
        return 'No tasks found.';
    }

    $output = '<ul>';
    foreach ($tasks as $task) {
        $output .= '<li>' . esc_html($task->title) . '</li>';
    }
    $output .= '</ul>';

    return $output;
}

add_shortcode('my_api_tasks', 'my_api_plugin_shortcode');

function my_api_plugin_get_logger() {
    $logger = new Logger('my_api_plugin');
    $logger->pushHandler(new StreamHandler(WP_CONTENT_DIR . '/logs/my_api_plugin.log', Logger::DEBUG));
    return $logger;
}